import 'package:cloud_firestore/cloud_firestore.dart';
import '../services/course_service.dart';
import '../models/SubjectRegistrationModel.dart';

class SubjectRegistrationController {
  final CourseService _courseService = CourseService();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Converts "HH:mm" to total minutes from midnight
  int _timeToMinutes(String timeStr) {
    try {
      final parts = timeStr.split(':');
      final hour = int.parse(parts[0]);
      final minute = int.parse(parts[1]);
      return hour * 60 + minute;
    } catch (e) {
      return 0;
    }
  }

  // Checks overlap: s1 < e2 && s2 < e1
  bool _isOverlapping(
    String day1,
    String start1,
    String end1,
    String day2,
    String start2,
    String end2,
  ) {
    if (day1.trim().toLowerCase() != day2.trim().toLowerCase()) return false;
    final s1 = _timeToMinutes(start1);
    final e1 = _timeToMinutes(end1);
    final s2 = _timeToMinutes(start2);
    final e2 = _timeToMinutes(end2);
    return s1 < e2 && s2 < e1;
  }

  // Checks duplicate registration (approved or pending) for the student
  Future<bool> checkAlreadyRegistered({
    required String studentEmail,
    required String subjectId,
  }) async {
    try {
      final QuerySnapshot existingRegs = await _firestore
          .collection('registrations')
          .where('studentEmail', isEqualTo: studentEmail)
          .where('subjectId', isEqualTo: subjectId)
          .get();

      for (var doc in existingRegs.docs) {
        final regData = doc.data() as Map<String, dynamic>;
        final String status = regData['status'] ?? 'pending';
        if (status == 'pending' || status == 'approved') {
          return true;
        }
      }
    } catch (_) {}
    return false;
  }

  // Checks schedule clashes against student's existing active registrations
  Future<bool> checkScheduleClash({
    required String studentEmail,
    required Map<String, dynamic> selectedLecture,
    required List<dynamic> selectedLabs,
  }) async {
    final QuerySnapshot existingRegs = await _firestore
        .collection('registrations')
        .where('studentEmail', isEqualTo: studentEmail)
        .get();

    for (var doc in existingRegs.docs) {
      final regData = doc.data() as Map<String, dynamic>;
      final String status = regData['status'] ?? 'pending';

      // Skip rejected registrations
      if (status == 'rejected') continue;

      final List<dynamic> regLectures = regData['lectures'] ?? [];
      final List<dynamic> regLabs = regData['labs'] ?? [];

      // 1. Check selected lecture against existing registered lectures
      for (var regLec in regLectures) {
        if (_isOverlapping(
          selectedLecture['day'] ?? '',
          selectedLecture['startTime'] ?? '',
          selectedLecture['endTime'] ?? '',
          regLec['day'] ?? '',
          regLec['startTime'] ?? '',
          regLec['endTime'] ?? '',
        )) {
          return true;
        }
      }

      // 2. Check selected lecture against existing registered labs
      for (var regLab in regLabs) {
        if (_isOverlapping(
          selectedLecture['day'] ?? '',
          selectedLecture['startTime'] ?? '',
          selectedLecture['endTime'] ?? '',
          regLab['day'] ?? '',
          regLab['startTime'] ?? '',
          regLab['endTime'] ?? '',
        )) {
          return true;
        }
      }

      // 3. Check selected labs against existing registered lectures
      for (var selLab in selectedLabs) {
        for (var regLec in regLectures) {
          if (_isOverlapping(
            selLab['day'] ?? '',
            selLab['startTime'] ?? '',
            selLab['endTime'] ?? '',
            regLec['day'] ?? '',
            regLec['startTime'] ?? '',
            regLec['endTime'] ?? '',
          )) {
            return true;
          }
        }
      }

      // 4. Check selected labs against existing registered labs
      for (var selLab in selectedLabs) {
        for (var regLab in regLabs) {
          if (_isOverlapping(
            selLab['day'] ?? '',
            selLab['startTime'] ?? '',
            selLab['endTime'] ?? '',
            regLab['day'] ?? '',
            regLab['startTime'] ?? '',
            regLab['endTime'] ?? '',
          )) {
            return true;
          }
        }
      }
    }

    return false;
  }

  // Submit subject registration for approval
  Future<void> submitRegistration({
    required String studentEmail,
    required String studentName,
    required String subjectId,
    required String subjectCode,
    required String subjectName,
    required String sectionName,
    String? labSectionName,
    required String examDate,
    required String examTime,
    required int creditHour,
    required List<dynamic> lectures,
    required List<dynamic> labs,
  }) async {
    final model = SubjectRegistrationModel(
      id: '', // Document ID will be auto-generated by Firestore
      studentEmail: studentEmail,
      studentName: studentName,
      subjectId: subjectId,
      subjectCode: subjectCode,
      subjectName: subjectName,
      sectionName: sectionName,
      labSectionName: labSectionName ?? '',
      lectures: lectures.map((lec) => Map<String, dynamic>.from(lec as Map)).toList(),
      labs: labs.map((lab) => Map<String, dynamic>.from(lab as Map)).toList(),
      status: 'pending',
      examDate: examDate,
      examTime: examTime,
      creditHour: creditHour,
    );
    await _courseService.submitRegistration(model);
  }
}
